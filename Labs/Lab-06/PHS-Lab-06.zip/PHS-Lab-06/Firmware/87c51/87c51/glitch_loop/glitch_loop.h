// glitch_loop.h

#ifndef GLITCH_LOOP_H
#define GLITCH_LOOP_H

void glitch_loop();

#endif // GLITCH_LOOP_H