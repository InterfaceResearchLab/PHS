// secret.h
// shhhh...

static const char stored_password[] = "Tr0ub4dor&3";