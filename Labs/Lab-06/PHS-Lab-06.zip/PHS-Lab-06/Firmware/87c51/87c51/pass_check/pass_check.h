// pass_check.h

#ifndef PASS_CHECK_H
#define PASS_CHECK_H

void check_password();

#endif // PASS_CHECK_H