Elliptic Curve Cryptography (ECC) over GF(2^163) HDL implementation by using three finit field cores.

The top level entity is ecc.v but you need to read all the files and ISE would sort these from top to bottom.

